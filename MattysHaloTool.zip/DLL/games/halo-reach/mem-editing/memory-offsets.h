#pragma once
namespace haloreach
{
	class memory_offsets
	{
	public:
		static int pancam_offset;
		static int infinite_grenades_offset;
		static int hs_print_opcode_offset;
		static int ai_spawning_effects_offset;
		static int ai_spawning_scripts_offset;
	};
}